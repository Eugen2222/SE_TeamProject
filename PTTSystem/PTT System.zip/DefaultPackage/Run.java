package DefaultPackage;

import ControllerPackage.LoginController;


public class Run {
	public static void main (String[] args) {
		LoginController start = new LoginController();
	}
	

	
}
